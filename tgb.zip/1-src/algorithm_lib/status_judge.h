#ifndef __STATUS_JUDGE_H__
#define __STATUS_JUDGE_H__
#include "status_judge.h"
int status_judge(float v, float threshold_prognosis, float threshold_prewarning, float threshold_warning);

#endif
