#ifndef mean_h
#define mean_h
float mean(float *buff,int size);


#endif
