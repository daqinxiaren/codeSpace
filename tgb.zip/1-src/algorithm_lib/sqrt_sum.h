#ifndef sqrt_sum_h
#define sqrt_sum_h
float sqrt_sum(float *buff, int size);


#endif
