#ifndef __MIN_H__
#define __MIN_H__

float min(float *buff,int N);
int min_int(int* buff, int N);

#endif

