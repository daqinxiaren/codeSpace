#ifndef __new_fft_H__
#define __new_fft_H__
#include "config.h"

float new_fft(float *buff, int size);
int fft_diag_init(void);

#endif 
