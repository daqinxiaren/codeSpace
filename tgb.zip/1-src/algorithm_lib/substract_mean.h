#ifndef substract_mean_h
#define substract_mean_h
void substract_mean(float *buff,int size);


#endif
