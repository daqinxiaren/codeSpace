#ifndef __main_h__
#define __main_h__
int main();
#endif