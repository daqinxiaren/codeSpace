#ifndef __fft_max_H__
#define __fft_max_H__

void fft_max(float *buff,float begin_fre,float end_fre,float fre_resolution,float *max_val,float *fft_val);

#endif
