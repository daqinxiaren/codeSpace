#ifndef rms_h
#define rms_h

float rms(float *src, int size);

#endif
